namespace ITU_projekt.Models
{
    public class LessonModel
    {
        public string LessonName { get; set; }
        public string LessonDescription { get; set; }
    }
}
